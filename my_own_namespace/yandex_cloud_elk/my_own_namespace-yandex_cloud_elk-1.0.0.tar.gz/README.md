# Ansible Collection - my_own_namespace.yandex_cloud_elk

Documentation for the collection.

## Modules
`plugins/modules/`
- `my_own_module` - This module creates a new file including some content

## Roles
`roles/`
- `create_file` - The role tests our module


